<?php

/* Register custom post types in here */

add_action('init', 'register_custom_post_types');
function register_custom_post_types()
{
    // Define post types in here
    // Learn how to create them here: http://codex.wordpress.org/Function_Reference/register_post_type
}
